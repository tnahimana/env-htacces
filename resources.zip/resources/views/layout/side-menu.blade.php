@extends('../layout/main')

@section('head')
    <title>@yield('title')</title>
@endsection

@section('content')
    @include('../layout/components/mobile-menu')
    <div class="flex">
        <!-- BEGIN: Side Menu -->
        <nav class="side-nav">
            <a href="/dashboard" class="intro-x flex items-center pl-5 pt-4">
                <img alt="Electrix Vending" class="w-6" src="{{ asset('dist/images/logo.svg') }}">
                <span class="hidden xl:block text-white text-lg ml-3">
                    Ele<span class="font-medium">trix</span>
                </span>
            </a>
            <div class="side-nav__devider my-6"></div>
            <ul>
                <li>
                    <a href="/dashboard" class="side-menu @yield('active-dashboard')">
                        <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                        <div class="side-menu__title">
                            Dashboard
                            <div class="side-menu__sub-icon transform rotate-180"> </div>
                        </div>
                    </a>
                </li>
                @if(auth()->user()->role->name == 'admin' || auth()->user()->role->name == 'super_admin')
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-admin')">
                            <div class="side-menu__icon"> <i data-feather="users"></i> </div>
                            <div class="side-menu__title">
                                Admins
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/admins" class="side-menu">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Admins </div>
                                </a>
                            </li>
                            @if(auth()->user()->role->name == 'super_admin')
                                <li>
                                    <a href="/admins/create" class="side-menu">
                                        <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                        <div class="side-menu__title"> Add Admin </div>
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-agent')">
                            <div class="side-menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="side-menu__title">
                                Agents
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/agents" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Agents </div>
                                </a>
                            </li>
                            <li>
                                <a href="/agents/create" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Add Agent </div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-meters')">
                            <div class="side-menu__icon"> <i class="fas fa-plug" style="font-size: 25px"></i> </div>
                            <div class="side-menu__title">
                                Meters
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/meters" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Meters </div>
                                </a>
                            </li>
                            {{-- <li>
                                <a href="/agents/create" class="side-menu @yield('active-agent')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Add Agent </div>
                                </a>
                            </li> --}}
                        </ul>
                    </li>
                @endif
                @if(auth()->user()->role->name != 'client')
                    <li>
                        <a href="javascript:;" class="side-menu @yield('active-client')">
                            <div class="side-menu__icon"> <i data-feather="user-check"></i> </div>
                            <div class="side-menu__title">
                                Clients
                                <div class="side-menu__sub-icon "> <i data-feather="chevron-down"></i> </div>
                            </div>
                        </a>
                        <ul class="">
                            <li>
                                <a href="/clients" class="side-menu @yield('active-client')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Clients </div>
                                </a>
                            </li>
                            <li>
                                <a href="/clients/create" class="side-menu @yield('active-client')">
                                    <div class="side-menu__icon"> <i data-feather="activity"></i> </div>
                                    <div class="side-menu__title"> Add Client </div>
                                </a>
                            </li>
                        </ul>

                    </li>
                @endif
            </ul>
        </nav>
        <!-- END: Side Menu -->
        <!-- BEGIN: Content -->
        <div class="content">
            @include('../layout/components/top-bar')
            @yield('subcontent')
        </div>
        <!-- END: Content -->
    </div>
@endsection
