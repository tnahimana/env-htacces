
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <link href="dist/images/logo.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Electrix Vending System">
    <meta name="keywords" content="Electrix,Smart Metering,Energy Solutions, Vending Software, Rwanda Energy">
    <meta name="author" content="Harris Technologies Ltd">
    <title>@yield('title')</title>
    @include('layout.components.loginStyle')
    @livewireStyles
</head>

<body style="background-color: rgb(26, 26, 114)">
  <div id="app">
    <section class="section">
      @yield('content')
    </section>
  </div>

  <!-- JS Libraies -->
  @include('layout.components.loginScript')
  @livewireScripts
  <!-- Page Specific JS File -->

</body>
</html>
