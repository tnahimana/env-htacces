<div class="container mt-2">
    <div class="row align-self-center">
        <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
        <div class="login-brand">
            <img src="../assets/img/electrix-logo-top.png" style="background-color: white" alt="logo" width="100" class="shadow-light rounded-circle">
        </div>

        <div class="card card-primary rounded-lg">
            <div class="card-header"><h4>Login</h4></div>

            <div class="card-body mt--2">
            @if(session('error'))
                <div class=" card card-danger">
                <div class="card-header">
                    <div class="btn alert-danger col-12">
                    {{ session('error') }}
                    </div>
                </div>
                </div>
            @endif
            <form wire:submit.prevent="login" class="needs-validation" novalidate="">
                <div class="form-group">
                <label for="email">Email</label>
                <input id="email" type="email" class="form-control" wire:model="email" tabindex="1" required autofocus>
                @error('email')
                    <div class="text-danger">
                        Please fill in your email
                    </div>
                @enderror
                </div>

                <div class="form-group">
                <div class="d-block">
                    <label for="password" class="control-label">Password</label>
                    <div class="float-right">
                    <a href="auth-forgot-password.html" class="text-small">
                        Forgot Password?
                    </a>
                    </div>
                </div>
                <input id="password" type="password" class="form-control" wire:model="password" tabindex="2" required>
                @error('password')
                    <div class="text-danger">
                        please fill in your password
                    </div>
                @enderror
                </div>

                <div class="form-group">
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" wire:model="remember" class="custom-control-input" tabindex="3" id="remember-me">
                    <label class="custom-control-label" for="remember-me">Remember Me</label>
                </div>
                </div>

                <div class="form-group">
                <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                    Login
                </button>
                </div>
            </form>

            </div>
        </div>
        </div>
    </div>
</div>
