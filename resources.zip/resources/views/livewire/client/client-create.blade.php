<div class="content" id="centered">
    <x-loading />
    <div class="grid grid-cols-12 gap-6 mt-5">
        <div class="intro-y col-span-12 place-items-center lg:col-span-12">
            <form action="POST" wire:submit.prevent="save">
                <div class="intro-y box mt-5" style="border-top: 3px solid blue">

                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div id="progressbar-color" class="p-5">
                            <div class="progress mt-3">
                                <div class="progress-bar @if($showPerson) w-1/4 @elseif($showAddress) w-2/4 @elseif($showRegMeter) w-3/4 @else w-full @endif  bg-theme-9" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="intro-y flex items-center mt-0 border-b border-gray-200 dark:border-dark-5 pb-4">
                        <h2 class="text-lg font-medium mr-auto mt-4 ml-6">Register Client</h2>
                    </div>

                    <div class="intro-y box mt-5">

                        <div class="flex justify-center items-center sm:ml-4 text-gray-600">
                            <h2 class="text-sm font-medium mr-auto mt-4 ml-6">
                                @if($showPerson)
                                Personal Information
                                @elseif($showAddress)
                                Address Information
                                @elseif($showRegMeter)
                                Reg Meter Information
                                @elseif($showElectrixMeter)
                                Electrix Meter Information
                                @endif
                            </h2>
                        </div>
                        
                        <div id="inline-form" class="p-5">
                            @if($showPerson)
                                <div class="container form-height">
                                    <div class="preview mr-5 ml-5">
                                        <div class="flex flex-wrap -mx-3 mb-2">
                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">First Name</label>
                                                    <input id="input-state-1" wire:model="firstname" type="text" class="form-control @error('firstname') border-theme-6 @elseif($firstname != "") border-theme-9 @enderror" placeholder="Firstname...">
                                                    @error('firstname')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-2" class="form-label">Middle Name</label>
                                                    <input id="input-state-2" wire:model="middlename" type="text" class="form-control @error('middlename') border-theme-6 @elseif($middlename != "") border-theme-9 @enderror" placeholder="Middlename...">
                                                    @error('middlename')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Last Name</label>
                                                    <input id="input-state-3" wire:model="lastname" type="text" class="form-control @error('lastname') border-theme-6 @elseif($lastname != "") border-theme-9 @enderror" placeholder="Lastname...">
                                                    @error('lastname')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">Email</label>
                                                    <input id="input-state-1" wire:model="email" type="email" class="form-control @error('email') border-theme-6 @elseif($email != "") border-theme-9 @enderror" placeholder="Email...">
                                                    @error('email')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-2" class="form-label">Phone</label>
                                                    <input id="input-state-2" wire:model="phone" type="text" class="form-control @error('phone') border-theme-6 @elseif($phone != "") border-theme-9 @enderror" placeholder="Phone..." maxlength="10">
                                                    @error('phone')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Gender</label>
                                                    <select id="input-state-3" wire:model="gender" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('gender') border-theme-6 @elseif($gender != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Gender --</option>
                                                        <option value="Male">Male</option>
                                                        <option value="Female">Female</option>
                                                    </select>
                                                    @error('gender')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Document Type</label>
                                                    <select id="input-state-3" wire:model="document_type" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('document_type') border-theme-6 @elseif($document_type != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="" selected>-- Select Document Type --</option>
                                                        @foreach($document as $item)
                                                            <option value="{{ $item->id }}">{{ $item->document_type }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('document_type')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">@if($document_type == null)Document @elseif($document_type == 1) NID @else Passport @endif Number</label>
                                                    <input id="input-state-1" wire:model="document_number" type="text" class="form-control @error('document_number') border-theme-6 @elseif($document_number != "") border-theme-9 @enderror" placeholder="@if($document_type == null)Document @elseif($document_type == 1) NID @else Passport @endif number..." @if($document_type == null) disabled @endif maxlength="16">
                                                    @error('document_number')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @elseif($showAddress)
                                <section class="container form-height">
                                    <div class="preview mr-5 ml-5">

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Province</label>
                                                    <select id="input-state-3" wire:model="province" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('province') border-theme-6 @elseif($province != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Province --</option>
                                                        @foreach($provinces as $item)
                                                            <option value="{{ $item->id }}">{{ $item->province }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('province')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">District</label>
                                                    <select id="input-state-3" wire:model="district" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('district') border-theme-6 @elseif($district != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select District --</option>
                                                        @foreach($districts as $item)
                                                            <option value="{{ $item->id }}">{{ $item->district }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('district')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Sector</label>
                                                    <select id="input-state-3" wire:model="sector" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('sector') border-theme-6 @elseif($sector != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Sector --</option>
                                                        @foreach($sectors as $item)
                                                            <option value="{{ $item->id }}">{{ $item->sector }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('sector')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Cell</label>
                                                    <select id="input-state-3" wire:model="cell" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('cell') border-theme-6 @elseif($cell != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Cell --</option>
                                                        @foreach($cells as $item)
                                                            <option value="{{ $item->id }}">{{ $item->cell }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('cell')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Village</label>
                                                    <select id="input-state-3" wire:model="village" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('village') border-theme-6 @elseif($village != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Village --</option>
                                                        @foreach($villages as $item)
                                                            <option value="{{ $item->id }}">{{ $item->village }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('village')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Type</label>
                                                    <select id="input-state-3" wire:model="meter_type" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_type') border-theme-6 @elseif($meter_type != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Meter Type --</option>
                                                            <option value="Residential">Residential</option>
                                                            <option value="Commercial">Commercial</option>
                                                        
                                                    </select>
                                                    @error('meter_type')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </section>
                            @elseif($showRegMeter)
                                <article class="container form-height">
                                    <div class="preview mr-5 ml-5">
                                        <div class="flex flex-wrap -mx-3 mb-2">
                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">Land UPI</label>
                                                    <input id="input-state-1" wire:model="upi" type="text" class="form-control @error('upi') border-theme-6 @elseif($upi != "") border-theme-9 @enderror" placeholder="-/--/--/--/----" maxlength="15">
                                                    @error('upi')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-2" class="form-label">Reg Meter Number</label>
                                                    <input id="input-state-2" wire:model="reg_meter_number" type="text" class="form-control @error('reg_meter_number') border-theme-6 @elseif($reg_meter_number != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="12">
                                                    @error('reg_meter_number')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Province</label>
                                                    <select id="input-state-3" wire:model="meter_province" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_province') border-theme-6 @elseif($meter_province != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Province --</option>
                                                        @foreach($meter_provinces as $item)
                                                            <option value="{{ $item->id }}">{{ $item->province }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_province')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location District</label>
                                                    <select id="input-state-3" wire:model="meter_district" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_district') border-theme-6 @elseif($meter_district != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select District --</option>
                                                        @foreach($meter_districts as $item)
                                                            <option value="{{ $item->id }}">{{ $item->district }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_district')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Sector</label>
                                                    <select id="input-state-3" wire:model="meter_sector" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_sector') border-theme-6 @elseif($meter_sector != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Sector --</option>
                                                        @foreach($meter_sectors as $item)
                                                            <option value="{{ $item->id }}">{{ $item->sector }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_sector')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Cell</label>
                                                    <select id="input-state-3" wire:model="meter_cell" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_cell') border-theme-6 @elseif($meter_cell != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Cell --</option>
                                                        @foreach($meter_cells as $item)
                                                            <option value="{{ $item->id }}">{{ $item->cell }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_cell')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                        <div class="flex flex-wrap -mx-3 mb-2">

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Meter Location Village</label>
                                                    <select id="input-state-3" wire:model="meter_village" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('meter_village') border-theme-6 @elseif($meter_village != "") border-theme-9 @enderror"
                                                    >
                                                        <option value="">-- Select Village --</option>
                                                        @foreach($meter_villages as $item)
                                                            <option value="{{ $item->id }}">{{ $item->village }}</option>
                                                        @endforeach
                                                        
                                                    </select>
                                                    @error('meter_village')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div class="md:mr-2">
                                                    <label for="input-state-1" class="form-label">Street Number</label>
                                                    <input id="input-state-1" wire:model="street" type="text" class="form-control @error('street') border-theme-6 @elseif($street != "") border-theme-9 @enderror" placeholder="KK 340 St" maxlength="15">
                                                    @error('street')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                            <div class="w-full md:w-1/3 px-3 mb-6 md:mb-0">
                                                <div>
                                                    <label for="input-state-3" class="form-label">Required Meters</label>
                                                    <select id="input-state-3" wire:model="selected" class="form-select box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                        py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500 @error('selected') border-theme-6 @elseif($selected != "") border-theme-9 @enderror"
                                                    >
                                                        <option class="text-center" value="">-- Select Number of Meters --</option>
                                                        @for($i = 1; $i <= 10; $i++)
                                                            <option class="text-left text-lg" value="{{ $i }}">{{ $i <= 9 ? '0'.$i : $i }}</option>
                                                        @endfor
                                                        
                                                    </select>
                                                    @error('selected')
                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                    @enderror
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </article>
                            @elseif($showElectrixMeter)
                                <main class="container @if($selected < 3)form-height @endif">
                                    <div class="preview mr-5 ml-5">
                                        <div class="grid grid-flow-col gap-3">
                                            <div class="bg-grey-100 col-span-1">

                                                <div class="flex flex-wrap -mx-3 mb-2">
                                                    <div class="w-full md:w-4/5 px-3 mb-6 md:mb-0">
                                                        <div>
                                                            <label for="input-state-3" class="form-label">Required Meters</label>
                                                            <select id="input-state-3" wire:model="selected" class="form-select text-lg text-black box mt-3 sm:mt-0 block w-full  border border-gray-300 text-gray-700 
                                                                py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-gray-500" disabled
                                                            >
                                                                <option class="text-center" value="">-- No Required Meters --</option>
                                                                @for($i = 1; $i <= 10; $i++)
                                                                    <option class="text-center text-lg" value="{{ $i }}">{{ $i }}</option>
                                                                @endfor
                                                                
                                                            </select>
                                                            @error('selected')
                                                                <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                            @enderror
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="bg-grey-100 col-span-4">

                                                <div class="flex flex-wrap -mx-3 mb-2">

                                                    <div class="w-full px-3 mb-6 md:mb-0">
                                                        <div class="md:mr-2">
                                                            <label for="input-state-2" class="form-label">Meter Number</label>
                                                                @if($selected == 1)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 2)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 3)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 4)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 5)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 6)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 7)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 8)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 9)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 @error('meter_number9') border-theme-6 @elseif($meter_number9 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number9')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @elseif($selected == 10)
                                                                    <input id="input-state-2" wire:model="meter_number1" type="text" class="form-control mt-3 @error('meter_number1') border-theme-6 @elseif($meter_number1 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number1')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number2" type="text" class="form-control mt-3 @error('meter_number2') border-theme-6 @elseif($meter_number2 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number2')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number3" type="text" class="form-control mt-3 @error('meter_number3') border-theme-6 @elseif($meter_number3 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number3')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number4" type="text" class="form-control mt-3 @error('meter_number4') border-theme-6 @elseif($meter_number4 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number4')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number5" type="text" class="form-control mt-3 @error('meter_number5') border-theme-6 @elseif($meter_number5 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number5')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number6" type="text" class="form-control mt-3 @error('meter_number6') border-theme-6 @elseif($meter_number6 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number6')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number7" type="text" class="form-control mt-3 @error('meter_number7') border-theme-6 @elseif($meter_number7 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number7')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number8" type="text" class="form-control mt-3 @error('meter_number8') border-theme-6 @elseif($meter_number8 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number8')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number9" type="text" class="form-control mt-3 @error('meter_number9') border-theme-6 @elseif($meter_number9 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number9')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                    <input id="input-state-2" wire:model="meter_number10" type="text" class="form-control mt-3 @error('meter_number10') border-theme-6 @elseif($meter_number10 != "") border-theme-9 @enderror" placeholder="Meter Number..." maxlength="11">
                                                                    @error('meter_number10')
                                                                        <div class="text-theme-6 mt-2">{{ $message }}</div>
                                                                    @enderror
                                                                @endif
                                                        </div>
                                                    </div>
                                                    
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </main>
                            @endif
                            <div id="input-state"  class="p-5 flex flex-wrap items-end justify-end -mt-2"> 
                                @if(!$showSubmit)
                                    @if(!$showPerson)        
                                    <button style="background-color: rgb(17, 17, 134)" wire:click="previous" @if($hidePrevious) disabled @endif type="button" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left -mt-2 w-4 h-4 mr-2 text-lg"></i> Previous  </button>
                                    @endif
                                    <button style="background-color: rgb(17, 17, 134)" wire:click="next" @if($hideNext) disabled @endif type="button" class="btn btn-primary pl-5 pr-5 mt-5 mb-2"> Next <i class="fas fa-angle-double-right -mt-2 w-4 h-4 ml-2 text-lg"></i></button>
                                @else
                                    <button style="background-color: rgb(17, 17, 134)" wire:click="previous" @if($hidePrevious) disabled @endif type="button" class="btn btn-primary pl-3 pr-3 mt-5 mr-2 mb-2"><i class="fas fa-angle-double-left -mt-2 w-4 h-4 mr-2 text-lg"></i> Previous  </button>
                                    <button style="background-color: rgb(17, 17, 134)" type="submit" class="btn btn-primary pl-5 pr-5 mt-5 mb-2"> Submit </button>
                                @endif
                            </div>
                        </div>
                        
                        
                    </div>
                    
                </div>
            </form>
        </div>

    </div>    
</div>