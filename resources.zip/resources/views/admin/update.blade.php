@extends('../layout/' . $layout)

@section('title')
    Update Admin Info | Electrix Vending
@endsection

@section('active-admin')
    side-menu--active
@endsection

@section('navigation')
    Update Admin Info
@endsection

@section('navigation-url')
    admins/{{ $id }}/edit
@endsection

@section('subcontent')
    @livewire('admin.admin-update',['id' => $id])
@endsection