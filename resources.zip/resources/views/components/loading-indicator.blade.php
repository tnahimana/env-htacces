{{-- <div  class="flex justify-center items-center" style="position:fixed; z-index: 9999; top: 0px; left: 0px;  width: 100%; height: 100%; opacity: .75"> --}}
    {{-- <div id="preloader"></div> --}}
{{-- </div> --}}
<div id="loader" class="flex justify-center items-center" style="background-color: black;
    position:fixed; top: 0px; left: 0px; z-index: 9999; width: 100%; height: 100%; opacity: .75">
    <div class="la-ball-spin la-3x">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>