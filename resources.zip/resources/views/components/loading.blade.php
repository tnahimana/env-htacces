<div wire:loading.delay>
    <div class="flex justify-center items-center" style="background-color: black;
    position:fixed; top: 0px; left: 0px; z-index: 9999; width: 100%; height: 100%; opacity: .75">
        <div class="la-ball-spin la-2x">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>