@extends('../layout/' . $layout)

@section('title')
    Agents | Electrix Vending
@endsection

@section('active-agent')
    side-menu--active
@endsection

@section('navigation')
    Agents
@endsection

@section('navigation-url')
    agents
@endsection

@section('subcontent')
    @livewire('agent.agent-index')
@endsection