@extends('../layout/' . $layout)

@section('title')
    Update Client Info | Electrix Vending
@endsection

@section('active-client')
    side-menu--active
@endsection

@section('navigation')
    Update Client Info
@endsection

@section('navigation-url')
    clients/{{ $client }}/edit
@endsection

@section('subcontent')
    @livewire('client.client-update',['id' => $client])
@endsection